<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(RoleSeeder::class);
        $this->call(balloons::class);
        $this->call(PerfectGiftSeeder::class);
        $this->call(GreetingsAppreciationCategorySeeder::class);
        $this->call(ECardCategorySeeder::class);
        $this->call(GustoServiceSeeder::class);
    }
}